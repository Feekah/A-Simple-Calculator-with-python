#You need to create a simple calculator using GUI programing. 
#The graphical interface should allow the user to enter a number in a text field and either add it to or subtract it from a running total. 
#The running total should always be displayed. The user should be able to resit the running total to zero using a button Resit. 
#The user will need to input a new value and then either press the button “+” to add the value to the running total or press “-” button to decrement the value in the entry from the running total. Each time the buttons “+” or “-” are pressed, the entry will be cleared and the running total will be updated.

import tkinter                                                                                                  #Import tkinter module

from numpy import double                                                                                        #Import double from numpy module           

x = 0                                                                                                           #Set x to 0            


class Calculator_GUI:                                                                                           #Create class Calculator_GUI               
    def __init__(self):                                                                                         #Create init method
        
       
        self.mw = tkinter.Tk()                                                                                  #Create main window

        
        self.mw.title("Simple Calculator")                                                                      #Set title of main window             

       
        self.top_frame = tkinter.Frame(self.mw)                                                                 #Create top frame    
        self.middle_frame = tkinter.Frame(self.mw)                                                              #Create middle frame
        self.bottom_frame = tkinter.Frame(self.mw)                                                              #Create bottom frame

        
        self.description_label = tkinter.Label(self.top_frame, text = "Total: ")                                #Create description label for top fame

        
        self.total = tkinter.StringVar()                                                                        #Create StringVar object that will store the total

       
        self.result_label = tkinter.Label(self.top_frame, textvariable= self.total)                             #Create result label for top frame

       
        self.description_label.pack(side="left")                                                                #Pack description label for top frame
        self.result_label.pack(side="left")                                                                     #Pack result label for top frame


       
        self.num_entry = tkinter.Entry(self.middle_frame, width= 25)                                            #Create entry widget for middle frame

       
        self.num_entry.pack(side="left")                                                                        #Pack entry widget for middle frame

        
        self.add_button = tkinter.Button(self.bottom_frame, text = "+", command=self.Sum)                       #Create add button for bottom frame
        self.subtract_button = tkinter.Button(self.bottom_frame, text = "-", command=self.Subtract)             #Create subtract button for bottom frame
        self.Reset_button = tkinter.Button(self.bottom_frame, text = "Reset", command=self.Reset)               #Create reset button for bottom frame

        
        self.add_button.pack(side="left")                                                                       #Pack add button for bottom frame
        self.subtract_button.pack(side="left")                                                                  #Pack subtract button for bottom frame
        self.Reset_button.pack(side="left")                                                                     #Pack reset button for bottom frame

       
        self.top_frame.pack()                                                                                   #Pack top frame
        self.middle_frame.pack()                                                                                #Pack middle frame      
        self.bottom_frame.pack()                                                                                #Pack bottom frame

        tkinter.mainloop()                                                                                      #Enter tkinter main loop      

    def Sum(self):                                                                                              #Create Sum method         
        global x                                                                                                #Declare x as global variable  
        entry1 = float(self.num_entry.get())                                                                   #Get value from entry widget   
        x += entry1                                                                                             #Add value to x
        self.num_entry.delete(0, tkinter.END)                                                                   #Delete value from entry widget     

        return self.total.set(str(x))                                                                                #Set total to x         

    def Subtract(self):                                                                                         #Create Subtract method             
        global x                                                                                                #Declare x as global variable      
        entry1 = float(self.num_entry.get())                                                                   #Get value from entry widget  
        x-= entry1                                                                                              #Subtract value from x
        self.num_entry.delete(0, tkinter.END)                                                                   #Delete value from entry widget    
        return self.total.set(str(x))                                                                                #Set total to x 

    def Reset(self):                                                                                            #Create Reset method    
        global x                                                                                                #Declare x as global variable       
        x = 0                                                                                                   #Set x to 0
        return self.total.set(str(x))                                                                                #Set total to x 
        

gui = Calculator_GUI()                                                                                          #Create instance of Calculator_GUI class      



